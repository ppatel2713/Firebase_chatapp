//
//  Constants.swift
//  FireChat
//
//  Created by Prachi on 2021-03-16.
//

import Firebase

//create messages collection in db
let COLLECTION_MESSAGES =  Firestore.firestore().collection("messages")


let COLLECTION_USERS = Firestore.firestore().collection("users")
