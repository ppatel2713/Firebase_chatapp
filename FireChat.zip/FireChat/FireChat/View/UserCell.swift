//
//  UserCell.swift
//  FireChat
//
//  Created by Prachi on 2021-03-10.
//

import UIKit
import SDWebImage

class UserCell : UITableViewCell
{
    var user : User?
    {
        didSet{
            configure()
        }
    }
    //MARK: - Properties
    private let profileImageView : UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFill
        iv.clipsToBounds = true
        return iv
    }()
    private let userLabel : UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 15)
        return label
    }()
    private let fullNameLabel : UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 12)
        label.textColor = .gray
        return label
    }()
    
    //MARK: - Lifecycle
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        addSubview(profileImageView)
        profileImageView.centerY(inView: self,leftAnchor: leftAnchor,paddingLeft: 12)
        profileImageView.setDimensions(height: 56, width: 56)
        profileImageView.layer.cornerRadius = 64 / 2
        let stack = UIStackView(arrangedSubviews: [userLabel,fullNameLabel])
        stack.axis = .vertical
        stack.spacing = 2
        
        addSubview(stack)
        stack.centerY(inView: profileImageView,leftAnchor: profileImageView.rightAnchor,paddingLeft: 12)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //MARK: - Helper
    func configure()  {
        guard let user = user else {
            return
        }
        fullNameLabel.text = user.fullName
        userLabel.text = user.userName
        
        guard let url = URL(string: user.profileImageUrl) else { //profileimageurl has just url so sdwebimage pod will convert url into image
            return
        }
        profileImageView.sd_setImage(with: url)
    }
} 
