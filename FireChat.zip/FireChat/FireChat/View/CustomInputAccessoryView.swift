//
//  CustomInputAccessoryView.swift
//  FireChat
//
//  Created by Prachi on 2021-03-12.
//

import UIKit
protocol CustomInputAccessoryViewDelegate : class
{
    func inputVeiew(_ inputView : CustomInputAccessoryView,wantsTosend message : String)
}
class CustomInputAccessoryView : UIView{
    //MARK: -Properties
    
    weak var delegate : CustomInputAccessoryViewDelegate?
   private let messageInputView : UITextView = {
        let TxtView =  UITextView()
        TxtView.font = UIFont.systemFont(ofSize: 16)
        TxtView.isScrollEnabled = false
        return TxtView
    }()
    
    private lazy var sendButton : UIButton = {
        let button =  UIButton(type: .system)
        button.setTitle("Send", for: .normal)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 14)
        button.setTitleColor(.systemPurple, for:.normal)
        button.addTarget(self, action: #selector(handleSendMessage), for: .touchUpInside)
        return button
    }()
    
     let placeHolder : UILabel =
    {
            let label = UILabel()
        label.text = "Enter Message..."
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = .lightGray
        return label
    }()
    //MARK: - LifeCycle
    override init(frame: CGRect) {
        super.init(frame: frame)
        layer.shadowOpacity = 0.5
        layer.shadowRadius = 10
        layer.shadowOffset = .init(width: 0, height: -8)
        layer.shadowColor = UIColor.purple.cgColor
        backgroundColor = .white
        autoresizingMask = .flexibleHeight //it will use on d/f screen sizing so has to flexible
        addSubview(sendButton)
        sendButton.anchor(top:topAnchor,right: rightAnchor,paddingTop: 4,paddingRight: 8)
        sendButton.setDimensions(height: 50, width: 50)
        addSubview(messageInputView)
        messageInputView.anchor(top:topAnchor,left: leftAnchor,
                                bottom:safeAreaLayoutGuide.bottomAnchor,
                                right: sendButton.leftAnchor,
                                paddingTop: 12,
                                paddingLeft: 8,
                                paddingBottom: 8,
                                paddingRight: 8)
        addSubview(placeHolder)
        placeHolder.anchor(left:messageInputView.leftAnchor,paddingLeft: 4)
        placeHolder.centerY(inView: messageInputView)
        
        
        
        NotificationCenter.default.addObserver(self, selector: #selector(handleTextInputChange), name: UITextView.textDidChangeNotification, object: nil)
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override var intrinsicContentSize: CGSize{
        return . zero
    }
    
    //MARK: - Helper
    func clearMessageText()
    {
        messageInputView.text = nil
        placeHolder.isHidden = false
    }
    
    //MARK: - Selector
    
    @objc func handleSendMessage()
    {
        guard let textMessage = messageInputView.text else {
            return
        } //check is there somethinf inside textview or not means user types meesage or not if typed then it will send it to function
        delegate?.inputVeiew(self, wantsTosend: textMessage)
    }
    
    @objc func handleTextInputChange() //placeholder text will remove
    {
        placeHolder.isHidden = !self.messageInputView.text.isEmpty
    }
    
    
}

