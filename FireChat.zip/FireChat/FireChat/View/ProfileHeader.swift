//
//  ProfileHeader.swift
//  FireChat
//
//  Created by Prachi on 2021-03-17.
//

import UIKit

protocol profileHeaderDelegate : class {
    func dismissController()
}

class ProfileHeader : UIView {
    //MARK: - Properties
    var user : User?
    {
        didSet{
            populateUserData()
        }
    } //call func when user is set, when user prop. get set call this func
    
    
    weak var delegate : profileHeaderDelegate?
    
    private let dismissButton : UIButton = {
        let button = UIButton(type: .system)
        button.setImage(UIImage(systemName: "xmark"), for: .normal)
        button.addTarget(self, action: #selector(handleDismiss), for: .touchUpInside)
        button.tintColor = .white
        button.imageView?.setDimensions(height: 22, width: 22)
        return button
    }()
    
    let profileImageView : UIImageView =
     {
         let iv = UIImageView()
         iv.contentMode = .scaleAspectFill
         iv.clipsToBounds = true
        iv.layer.borderColor = UIColor.white.cgColor
        iv.layer.borderWidth = 4.0
         return iv
     }()
    
    let userLabel1 : UILabel =
    {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = .white
        label.textAlignment = .center
        return label
    }()
    
    let fullNameLabel1 : UILabel =
    {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 20)
        label.textColor = .white
        label.textAlignment = .center
        return label
    }()
    
    
    //MARK: - LifeCycle
    override init(frame: CGRect) {
        super.init(frame: frame)
        configGradientLayOut()
        configUI()
    }
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //MARK: - Helper
    func configGradientLayOut()
    {
        let gradient = CAGradientLayer()
        gradient.colors = [UIColor.systemPurple.cgColor,UIColor.systemPink.cgColor]
        gradient.locations = [0, 1]
        layer.addSublayer(gradient)
        gradient.frame = bounds
    }
    func populateUserData() {
        guard let user = user else {
            return
        }
        fullNameLabel1.text = user.fullName
        userLabel1.text = "@" + user.userName
        
        guard let url = URL(string: user.profileImageUrl) else {
            return
        }
        profileImageView.sd_setImage(with: url, completed: nil)
    }
    func configUI()
    {
        profileImageView.setDimensions(height: 200, width: 200)
        profileImageView.layer.cornerRadius = 200 / 2
        addSubview(profileImageView)
        profileImageView.centerX(inView: self)
        profileImageView.anchor(top:topAnchor,paddingTop: 96)
        
        
        let stack = UIStackView(arrangedSubviews: [fullNameLabel1,userLabel1])
        stack.axis = .vertical
        stack.spacing = 4
        
        addSubview(stack)
        stack.centerX(inView: self)
        stack.anchor(top:profileImageView.bottomAnchor, paddingTop: 4)
        
        addSubview(dismissButton)
        dismissButton.anchor(top:topAnchor,left: leftAnchor,paddingTop: 44,paddingLeft: 12)
        dismissButton.setDimensions(height: 48, width: 48)
        
    }
   
    //MARK: -Selectors
    @objc func handleDismiss()
    {
        delegate?.dismissController() //calling func from profileheaderdelegate. definition is in profileController
    }
    
    //MARK: - API
}
