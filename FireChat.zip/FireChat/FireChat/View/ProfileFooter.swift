//
//  ProfileFooter.swift
//  FireChat
//
//  Created by Prachi on 2021-03-17.
//

import UIKit
protocol ProfileFooterDelegate : class {
    func handleLogOut()
} //created delegate for logging out from app bcz its inside of custom view class.
class ProfileFooter : UIView
{
    //MARK: - Properties
    
    weak var delegate : ProfileFooterDelegate?
    
    private lazy var logoutButton : UIButton = {
        let button = UIButton(type: .system)
        button.layer.cornerRadius = 7
        button.setTitle("Logout", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        button.backgroundColor = .systemPink
        button.addTarget(self, action:#selector(handleLogOut), for: .touchUpInside)
        return button
    }()
    
    //MARK: -LifeCycle
    override init(frame: CGRect) {
        super.init(frame: frame )
        
        addSubview(logoutButton)
        logoutButton.anchor(left:leftAnchor,right: rightAnchor,paddingLeft: 32,paddingRight: 32)
        logoutButton.heightAnchor.constraint(equalToConstant: 50).isActive = true
        logoutButton.centerY(inView: self)
    }
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

    //MARK: -Helper
    @objc func handleLogOut()
    {
        delegate?.handleLogOut()
    }
}
