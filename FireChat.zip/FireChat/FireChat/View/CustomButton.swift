//
//  CustomButton.swift
//  FireChat
//
//  Created by Prachi on 2021-03-08.
//

import UIKit

class CustomButton : UIButton
{
    init(text : String, color : UIColor?)
    {
        super.init(frame: .zero)
        setTitle(text, for:.normal)
        layer.cornerRadius = 5
       setHeight(height: 40)
        titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        backgroundColor = color
        setTitleColor(.white, for: .normal)
        isEnabled = true
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    convenience init(type: UIButton.ButtonType) {
           self.init(type: .system)
       }
    
}
