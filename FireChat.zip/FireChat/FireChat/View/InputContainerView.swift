//
//  InputContainerView.swift
//  FireChat
//
//  Created by Prachi on 2021-03-08.
//

import UIKit

class InputContainerView : UIView
{
    init(image : UIImage?, textField : UITextField)
    {
        super.init(frame: .zero)
        setHeight(height: 50)
        self.backgroundColor = .clear
        let iv = UIImageView()
        iv.tintColor = .white
        iv.image = image
        iv.alpha = 0.87
        addSubview(iv)
        iv.centerY(inView: self)
        iv.anchor(left: leftAnchor, paddingLeft: 10) //we want left side of view(envelope image)
        iv.setDimensions(height: 24, width: 24)
        
        addSubview(textField)
        textField.centerY(inView: self)
        textField.anchor(left:iv.rightAnchor,bottom:
                            bottomAnchor, right: rightAnchor,paddingLeft: 12, paddingBottom: -8) //for textfild left is imageview's right so distance between image and txtfld is 8
        textField.tintColor = .white
        textField.textColor = .white
        
        let dividerView = UIView()
        dividerView.backgroundColor = .white
        addSubview(dividerView)
        dividerView.anchor(left:leftAnchor,bottom: bottomAnchor,right: rightAnchor,paddingLeft: 8,height: 0.75)
        
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
