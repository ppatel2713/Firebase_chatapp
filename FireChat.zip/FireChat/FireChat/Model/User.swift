//
//  User.swift
//  FireChat
//
//  Created by Prachi on 2021-03-10.
//

import Foundation

struct User { //represent user in app, help to access all values from Database and all prop repesent database's info so all things uploaded into database under user table
    let uid : String
    let profileImageUrl : String
    let userName : String
    let fullName : String
    let email : String
    
    init(dictionary : [String : Any])
    {
        self.uid = dictionary["uid"] as? String ?? ""
        self.profileImageUrl = dictionary["profileImageURl"] as? String ?? ""
        self.userName = dictionary["username"] as? String ?? ""
        self.fullName = dictionary["fullname"] as? String ?? ""
        self.email = dictionary["email"] as? String ?? ""
        
    }
}
