//
//  Message.swift
//  FireChat
//
//  Created by Prachi on 2021-03-14.
//

import Firebase


struct Message {
    let text: String
    let toID : String //message to person
    let fromID : String //message from person
    var timeStamp : Timestamp! //firebase has this prop, what time message has been sent
    var user : User? //user prop. use to load data from user
    let isFromCurrentUser: Bool
    
    var chatPartnerId :String
    {
        return isFromCurrentUser ? toID : fromID
    }
    // if currtent is messaging somebody so coversation controller has list of toIDs. if mesasage is from current user than need whoever is from(means I send message to someone else so I need that person's data to showup there, I am someone who send msg)  and if not we need from ID
    init(dictionary : [String:Any]) {
        self.text = dictionary["text"] as? String ?? ""
        self.toID = dictionary["toID"] as? String ?? ""
        self.fromID = dictionary["fromID"] as? String ?? ""
        self.timeStamp = dictionary["timeStamp"] as? Timestamp ?? Timestamp(date: Date())
        
        self.isFromCurrentUser = fromID == Auth.auth().currentUser?.uid //asign fromID a current user
    }
}

struct Conversation { //creating this struct because we need to show user and last recent msg on main screen
    let user : User
    let message : Message

}
