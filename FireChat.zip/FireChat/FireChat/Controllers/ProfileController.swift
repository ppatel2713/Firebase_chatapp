//
//  ProfileController.swift
//  FireChat
//
//  Created by Prachi on 2021-03-17.
//

import UIKit
import Firebase

private let reuseIdentifier = "ProfileCell"

protocol ProfileControllerDelegate : class {
    func handleLogOut()
}
class ProfileController: UITableViewController {
    //MARK: - Properties
    
    weak var delegate : ProfileControllerDelegate?
    
    private var user : User?
    {
        didSet
        {
            headerView.user = user
        } //when user variable get sets it will populate with user info
    }
    
    private lazy var headerView = ProfileHeader(frame: .init(x: 0, y: 0, width: 500, height: 380)) //create header view
    
    
    private let footerView = ProfileFooter()
    
    
    //MARK: - LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        configUI()
        fetchUser()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.isHidden = true
        navigationController?.navigationBar.barStyle = .black
    }
    //MARK: - Helper
    
    func configUI()
    {
        tableView.backgroundColor = .white
        tableView.tableHeaderView = headerView
        tableView.register(ProfileCell.self, forCellReuseIdentifier: reuseIdentifier)
        tableView.contentInsetAdjustmentBehavior = .never //remove white status bar from top
        headerView.delegate = self //imp, confirming delegate
        footerView.delegate = self
        tableView.rowHeight = 60
        tableView.backgroundColor = .systemGroupedBackground
        
        footerView.frame = .init(x: 0, y: 0, width: view.frame.width, height: 100)
        tableView.tableFooterView = footerView
        
    }
    //MARK: -Selectors
    
    
    //MARK: - API
    
    func fetchUser()
    {
        guard let uid = Auth.auth().currentUser?.uid else {
            return
        }
        
        Service.fetchusersWithuID(withuID: uid) { user in
            self.user = user
        }
    }// fetching particular using who is currently working in app. pass this particular user into header
}
//MARK: -UITableViewDataSource and UITableViewDelegate

extension ProfileController
{
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ProfileViewModel.allCases.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath) as! ProfileCell
        let viewModel = ProfileViewModel(rawValue: indexPath.row) //0 will give accountInfo case and 1 will give settings
        cell.viewModel = viewModel
        cell.accessoryType = .disclosureIndicator  //add arrow in cell
        return cell
    } // when create custom cell use enum, code will be super clean and understandable
}

extension ProfileController : profileHeaderDelegate{
    func dismissController() {
        dismiss(animated: true, completion: nil)
    } //dismiss controller
}

extension ProfileController{
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let viewModel = ProfileViewModel(rawValue: indexPath.row) else {return}
        
        switch viewModel {
            case .accountInfo: print(viewModel.description)
            case .settings : print(viewModel.description)
        }
        
    }
    
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return UIView()
    }//put some space between tableview and big tableview
}


extension ProfileController : ProfileFooterDelegate{
    func handleLogOut() {
        let alert = UIAlertController(title: nil, message:"Are you sure Want to Log-Out?" , preferredStyle:.actionSheet)
        alert.addAction(UIAlertAction(title: "Log-Out", style:.destructive, handler: { _ in
            self.dismiss(animated: true) {
                self.delegate?.handleLogOut() //this method is from this class's delegate
            }
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}
//for logging out from app it starts from profilefooter delegate and than it will come to ProfileController delegate and then it will go to conversation controller, best practice to pass obj and delegates to VCs. this is chaining delegates
