//
//  LoginController.swift
//  FireChat
//
//  Created by Prachi on 2021-03-07.
//

import UIKit
import Firebase
import JGProgressHUD

protocol AuthenticationControllerProtocol {
    func checkFormStatus()
}

protocol AuthenticationDelegate : class {
    func authenticationComplete()
    
}
class LoginController: UIViewController {
    //MARK: - Properties
    private var viewModel = LoginViewModel()
    
    weak var delegate : AuthenticationDelegate?
    
    private let iconImage :UIImageView =
    {
        let iv = UIImageView()
        iv.image = UIImage(systemName: "bubble.right")
        iv.tintColor = .white
        return iv
    }()
    
    private lazy var emailContainerView: InputContainerView = {
        return InputContainerView(image:#imageLiteral(resourceName: "ic_mail_outline_white_2x"), textField: emailTextField)
        
        //lazy loading means it will not load that prop. untill evrything has been setup
    }()
    
    private lazy var  passwordContainerView: InputContainerView = {
        
        return InputContainerView(image: #imageLiteral(resourceName: "ic_lock_outline_white_2x"), textField: passwordTextField)
       //for getting imageLitreal type image litrel -> doubleclick
    }()
    
     let loginButton = CustomButton(text: "Login", color: #colorLiteral(red: 0.9098039269, green: 0.4784313738, blue: 0.6431372762, alpha: 1))
    

    private let dontHaveAccount : UIButton = {
        let button = UIButton(type: .system)
        let attributedTitle = NSMutableAttributedString(string: "Don't have an account? ", attributes: [.font : UIFont.systemFont(ofSize: 16)])
        
        attributedTitle.append(NSAttributedString(string: "Sign up", attributes: [.font : UIFont.boldSystemFont(ofSize: 16)]))
        attributedTitle.addAttributes([NSAttributedString.Key.foregroundColor : UIColor.white], range: NSRange (location:0, length:attributedTitle.length))
        button.setAttributedTitle(attributedTitle, for: .normal)
        button.addTarget(self, action: #selector(handleShowSignUp), for: .touchUpInside)
        return button
    }()
    
    
    //so here we are creating textfield outside of container view bcz we need information and text of that textfield so have to create class level proprties, if we create this inside container its hard to acces
    
    private let emailTextField: UITextField =  {
       let placeholder = CustomTextField(placeholder: "Enter Email")
        return placeholder
    }()
    
    
    private let passwordTextField : UITextField =
        {
           let passwordField =  CustomTextField(placeholder: "Enter Password")
            passwordField.isSecureTextEntry = true
            return passwordField
        }()
    
    //MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        configUI()
        
    }
    
    //MARK: - Selectors
    @objc func handleShowSignUp()
    {
        let registrationVC = Registrationcontroller()
        registrationVC.delegate = delegate //imp
        navigationController?.pushViewController(registrationVC , animated: true)
    }
    @objc func handleLoginButton()
    {
        guard let email = emailTextField.text,let password = passwordTextField.text else {return}
        showLoader(true, withText: "Logging in")
        
        AuthService.shared.logUserIn(withEmail: email, andWithPassword: password) { (result, error) in
            if let error = error
            {
                print("Fail to login:\(error.localizedDescription)")
               self.showLoader(false)
                let alert = UIAlertController(title: "Alert", message: "\(error.localizedDescription)", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler:nil))
                self.present(alert, animated: true, completion: nil)
                return
            }
            self.showLoader(false)
            self.delegate?.authenticationComplete() //call func from delegate protocol
        }//when the process complete dimiss code will excute

    }
    @objc func textDidChange(sender : UITextField) //we are passing sender bcz we need info from txtfield
    {
        if sender == emailTextField
        {
            viewModel.email = sender.text
        }
        else
        {
            viewModel.password = sender.text
        }
        checkFormStatus()
    }
    
    @objc func textFieldShouldReturn(sender: UITextField) -> Bool {
        return sender.resignFirstResponder()
    }
    
    //MARK: - Helper
    func configUI() {
        navigationController?.navigationBar.isHidden = true
        navigationController?.navigationBar.barStyle = .black
        confgGradientUI()
        view.addSubview(iconImage)
        iconImage.centerX(inView: view) //center in x
        iconImage.anchor(top:view.safeAreaLayoutGuide.topAnchor,paddingTop: 35) //35 distance from top
        iconImage.setDimensions(height: 120, width: 120)
    
        let stackView = UIStackView(arrangedSubviews: [emailContainerView,passwordContainerView,loginButton])
        stackView.axis = .vertical
        stackView.spacing = 16
        view.addSubview(stackView)
        stackView.anchor(top: iconImage.bottomAnchor, left: view.leftAnchor, right: view.rightAnchor, paddingTop: 32, paddingLeft: 32, paddingRight: 32)
        
        view.addSubview(dontHaveAccount)
        dontHaveAccount.anchor(left:view.leftAnchor,
                               bottom: view.safeAreaLayoutGuide.bottomAnchor,
                               right: view.rightAnchor,
                               paddingLeft: 32,
                               paddingBottom: 16,
                               paddingRight: 32)
        emailTextField.addTarget(self, action: #selector(textDidChange), for: .editingChanged)
        emailTextField.addTarget(self, action: #selector(textFieldShouldReturn(sender:)), for: .editingDidEndOnExit)
        passwordTextField.addTarget(self, action: #selector(textDidChange), for: .editingChanged)
        passwordTextField.addTarget(self, action: #selector(textFieldShouldReturn(sender:)), for: .editingDidEndOnExit)
                
        loginButton.addTarget(self, action: #selector(handleLoginButton), for: .touchUpInside)
    }
    
    //create gredient view
    func confgGradientUI()
    {
        let gredient = CAGradientLayer()
        gredient.colors = [UIColor.systemPink.cgColor, UIColor.systemPurple.cgColor]
        gredient.locations = [0,1]
        view.layer.addSublayer(gredient)
        gredient.frame = view.frame
        
    }
    //enable and disable the login button as per info in txtField
    
}

extension LoginController : AuthenticationControllerProtocol, UITextFieldDelegate
{
    func checkFormStatus()
    {
        if viewModel.isValidForm
        {
            loginButton.isEnabled = true
            loginButton.backgroundColor = #colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1)
        }
        else
        {
            loginButton.isEnabled = false
            loginButton.backgroundColor = #colorLiteral(red: 0.9098039269, green: 0.4784313738, blue: 0.6431372762, alpha: 1)
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return true
    }
}
