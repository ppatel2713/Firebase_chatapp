//
//  Registrationcontroller.swift
//  FireChat
//
//  Created by Prachi on 2021-03-07.
//

import UIKit
import Firebase
import JGProgressHUD

class Registrationcontroller: UIViewController {
    //MARK: - Properties
    var viewModel = RegisterViewModel()
    
    var profileImage : UIImage?
    weak var delegate : AuthenticationDelegate?
    private let addphotoButton  :UIButton =
    {
        let button = UIButton(type: .system)
        button.setImage(#imageLiteral(resourceName: "plus_photo"), for: .normal)
        button.tintColor = .white
        button.addTarget(self, action: #selector(handleProfilePicture), for: .touchUpInside)
        button.clipsToBounds = true
        button.imageView?.contentMode = .scaleAspectFill
        return button
    }()
    private lazy var emailContainerView: InputContainerView = {
        return InputContainerView(image:#imageLiteral(resourceName: "ic_mail_outline_white_2x"), textField: emailTextField)
        
        //lazy loading means it will not load that prop. untill evrything has been setup
    }()
    private lazy var fullnameContainerView: InputContainerView = {
        return InputContainerView(image: #imageLiteral(resourceName: "ic_person_outline_white_2x"), textField: fullNameTextField)
    }()
    
    private lazy var userNameContainerView: InputContainerView = {
        return InputContainerView(image: #imageLiteral(resourceName: "ic_person_outline_white_2x"), textField: usernameTextField)
    }()
    
    private lazy var  passwordContainerView: InputContainerView = {
        
        return InputContainerView(image: #imageLiteral(resourceName: "ic_lock_outline_white_2x"), textField: passwordTextField)
       //for getting imageLitreal type image litrel -> doubleclick
    }()
    
    private let emailTextField = CustomTextField(placeholder: "Enter Email")
    private let fullNameTextField = CustomTextField(placeholder: "Enter Full Name")
    private let usernameTextField = CustomTextField(placeholder: "Enter Username")
    
    private let passwordTextField : CustomTextField =
        {
           let passwordField =  CustomTextField(placeholder: "Enter Password")
            passwordField.isSecureTextEntry = true
            return passwordField
        }()
    
    private var signupButton = CustomButton(text: "Signup", color: #colorLiteral(red: 0.9098039269, green: 0.4784313738, blue: 0.6431372762, alpha: 1))
    
    private let alreadyHaveAccount : UIButton = {
        let button = UIButton(type: .system)
        let attributedTitle = NSMutableAttributedString(string: "Already have an account? ", attributes: [.font : UIFont.systemFont(ofSize: 16)])
        
        attributedTitle.append(NSAttributedString(string: "Login", attributes: [.font : UIFont.boldSystemFont(ofSize: 16)]))
        attributedTitle.addAttributes([NSAttributedString.Key.foregroundColor : UIColor.white], range: NSRange (location:0, length:attributedTitle.length))
        button.setAttributedTitle(attributedTitle, for: .normal)
        button.addTarget(self, action: #selector(handleShowLogin), for: .touchUpInside)
        return button
    }()
    //MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configUI()
        confgNotificationObserver()
    }
    
    //MARK: - Selectors
    @objc func keyBoardWillShow()
    {
        if view.frame.origin.y == 0
        {
            self.view.frame.origin.y -= 88
        }
    }
    
    @objc func keyBoardWillHide()
    {
        if view.frame.origin.y != 0
        {
            view.frame.origin.y = 0
        }
    }
    
    @objc func handleRegistration()
    {
        guard let email = emailTextField.text, let username = usernameTextField.text?.lowercased(), let fullName = fullNameTextField.text, let password = passwordTextField.text, let profileImage = profileImage  else { return }
     showLoader(true,withText: "Setting Up Profile")
        let credentials = RegistrationCredentials(email: email, password: password, fullName: fullName, userName: username, profileImage: profileImage)
        AuthService.shared.createUser(credentials: credentials) { error in
            if let error = error
            {
                print("Fail to setup:\(error.localizedDescription)")
                
                let alert = UIAlertController(title: "Alert", message: "\(error.localizedDescription)", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                self.showLoader(false)
                return

            }
            self.showLoader(false)
            self.delegate?.authenticationComplete()
        }//when the process complete dimiss code will excute
       
    }
    @objc func handleProfilePicture()
    {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        present(imagePicker, animated: true, completion: nil)
    }
    
    @objc func handleShowLogin()
    {
        navigationController?.popViewController(animated: true)
        
    }
    @objc func textDidChange(sender : UITextField) //we are passing sender bcz we need info from txtfield
    {
        if sender == emailTextField
        {
            viewModel.email = sender.text
        }
        else if sender == passwordTextField
        {
            viewModel.password = sender.text
        }
        else if sender == usernameTextField
        {
            viewModel.userName = sender.text
        }
        else if sender == fullNameTextField
        {
            viewModel.fullName = sender.text
        }
        checkFormStatus()
    }
    
   
    //MARK: - Helper
    //create gredient view
    
   
    func confgGradientUI()
    {
        let gredient = CAGradientLayer()
        gredient.colors = [UIColor.systemPink.cgColor, UIColor.systemPurple.cgColor]
        gredient.locations = [0,1]
        view.layer.addSublayer(gredient)
        gredient.frame = view.frame
        
    }
    func configUI() {
        navigationController?.navigationBar.isHidden = true
        navigationController?.navigationBar.barStyle = .black
        confgGradientUI()
        view.addSubview(addphotoButton)
        addphotoButton.centerX(inView: view) //center in x
        addphotoButton.anchor(top:view.safeAreaLayoutGuide.topAnchor,paddingTop: 5) //35 distance from top
        addphotoButton.setDimensions(height: 200, width: 200)
        
        let stackView = UIStackView(arrangedSubviews: [emailContainerView,fullnameContainerView,userNameContainerView,passwordContainerView,signupButton])
        stackView.axis = .vertical
        stackView.spacing = 10
        view.addSubview(stackView)
        stackView.anchor(top: addphotoButton.bottomAnchor, left: view.leftAnchor, right: view.rightAnchor, paddingTop: 8, paddingLeft: 32, paddingRight: 32)
        
        view.addSubview(alreadyHaveAccount)
        alreadyHaveAccount.anchor(left:view.leftAnchor,
                               bottom: view.safeAreaLayoutGuide.bottomAnchor,
                               right: view.rightAnchor,
                               paddingLeft: 32,
                               paddingBottom: 16,
                               paddingRight: 32)
        
        
    }
    
    func confgNotificationObserver() {
        emailTextField.addTarget(self, action: #selector(textDidChange), for: .editingChanged)
        passwordTextField.addTarget(self, action: #selector(textDidChange), for: .editingChanged)
        usernameTextField.addTarget(self, action: #selector(textDidChange), for: .editingChanged)
        fullNameTextField.addTarget(self, action: #selector(textDidChange), for: .editingChanged)
        signupButton.addTarget(self, action: #selector(handleRegistration), for: .touchUpInside)
        NotificationCenter.default.addObserver(self, selector: #selector(keyBoardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyBoardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
}
//MARK: - PickerViewDelegates
extension Registrationcontroller : UIImagePickerControllerDelegate,UINavigationControllerDelegate
{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let pickingImage = info[.originalImage] as? UIImage
        profileImage = pickingImage
        addphotoButton.setImage(pickingImage?.withRenderingMode(.alwaysOriginal), for: .normal)
        addphotoButton.layer.borderColor = UIColor.white.cgColor
        addphotoButton.layer.borderWidth = 3.0
        addphotoButton.layer.cornerRadius = 100
        dismiss(animated: true, completion: nil)
    }
}
extension Registrationcontroller : AuthenticationControllerProtocol
{
    func checkFormStatus()
    {
        if viewModel.isValidForm
        {
            signupButton.isEnabled = true
            signupButton.backgroundColor = #colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1)
        }
        else
        {
            signupButton.isEnabled = false
            signupButton.backgroundColor = #colorLiteral(red: 0.9098039269, green: 0.4784313738, blue: 0.6431372762, alpha: 1)
        }
    }
}
