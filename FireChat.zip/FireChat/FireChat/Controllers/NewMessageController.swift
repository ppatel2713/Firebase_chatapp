//
//  NewMessageController.swift
//  FireChat
//
//  Created by Prachi on 2021-03-10.
//

import UIKit
private let reuseIdentifier : String = "NewMessageCell"

protocol NewMessageControllerDelegate : class
{
    func controller(_ controller : NewMessageController, wantsToChatWith user:User)
}//whatever class implement this ptocol, has to implement this func. this protocol creates because when user is tapping in users from list it has to invoked which user is selected and have to dismiss this controller and present converstation of that particular user
class NewMessageController: UITableViewController {
    
    //MARK: - Properties
    private var users = [User]()
    private var fileredUser = [User]() //using for search user
    weak var delegate : NewMessageControllerDelegate? // type of NewMessageControllerDelegate so it has to set in every controller which confirms NewMessageControllerDelegate  
    private var inSearchMode : Bool
    {
        return searchController.isActive && !searchController.searchBar.text!.isEmpty
    }
    //search controller
    private let searchController = UISearchController(searchResultsController: nil)
    
    //MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        configUI()
        configSearchController()
        fetchUsers()
    }
    
    //MARK: - Selectors
    @objc func handeleCancelButton()
    {
        dismiss(animated: true, completion: nil)
    }
    //MARK: - API
    
    func fetchUsers() {
        
        showLoader(true)
        Service.fetchusers { users in
            self.showLoader(false)
            self.users = users //users comes from service file and assign here to users array for displaying in table
            self.tableView.reloadData() //after updating array has to relaod data in tableview and when screen loading array is 0 then its intailize with count so after that it will update data
            
        }
    }
    //MARK: - Helper
    func configUI() {
        configureNavigationBar(withTitle: "New Messages", prefertLargeTitle: false)
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(handeleCancelButton))
        
        tableView.tableFooterView = UIView()
        tableView.register(UserCell.self, forCellReuseIdentifier: reuseIdentifier) 
        tableView.rowHeight = 80
        
    }
    
    func configSearchController() {
        searchController.searchResultsUpdater = self
        searchController.searchBar.showsCancelButton = false
        navigationItem.searchController = searchController
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.hidesNavigationBarDuringPresentation = false
        searchController.searchBar.placeholder = "Search for user"
        definesPresentationContext = false
        
        if let textfield  = searchController.searchBar.value(forKey: "searchField") as? UITextField
        {
            textfield.textColor = .systemPurple
            textfield.backgroundColor = .white
        }
    }
}

//MARK: - TableViewDataSource

extension NewMessageController
{
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return inSearchMode ? fileredUser.count : users.count
    } //if something is written is searchbar so return count as per text otherwise return user.count
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath) as! UserCell
        
        cell.user = inSearchMode ? fileredUser[indexPath.row] : users[indexPath.row] //asign users each element to cell's user. ex: 1st user go into 0th position of tableview and so on
        
        return cell
    }
}
extension NewMessageController
{
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let user = inSearchMode ? fileredUser[indexPath.row] : users[indexPath.row]
       // print(users[indexPath.row].userName)
        delegate?.controller(self, wantsToChatWith:user)
    }
}
 //MARK: -Searchbar

extension NewMessageController : UISearchResultsUpdating
{
    func updateSearchResults(for searchController: UISearchController) {
        guard let searchText = searchController.searchBar.text?.lowercased() else {return}
        fileredUser = users.filter({ user -> Bool in
            return user.userName.contains(searchText) || user.fullName.contains(searchText)
            
        })
        self.tableView.reloadData()
    } //code of search result which matches with search query
}
