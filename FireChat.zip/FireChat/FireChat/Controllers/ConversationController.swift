//
//  ConversationController.swift
//  FireChat
//
//  Created by Prachi on 2021-03-07.
//

import UIKit
import Firebase


private let reuseIdentifier : String = "ConversationCell"


class ConversationController : UIViewController
{
    //MARK: - Properties
    private var conversations = [Conversation]()
    private let tableView = UITableView()
    private var conversationDictionary = [String : Conversation]() //for fetching conversation. key(sender and receiver) will remail same and value will change(Conversation is messages). we can keep track of conversation with unique key, means key already exist just update conversation no need to create new conversation everytime
    
    private let newMessage : UIButton = {
        let button = UIButton(type: .system)
        button.setImage(UIImage(systemName: "plus"), for: .normal)
        button.backgroundColor = UIColor.systemPurple
        button.tintColor = UIColor.white
        button.imageView?.setDimensions(height: 24, width: 24)
        button.addTarget(self, action: #selector(showNewMessageController), for: .touchUpInside)
        return button
    }()
    
    //MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        configUI()
        authenticateUSER()
        fetchConversation()
        tableView.reloadData()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        configureNavigationBar(withTitle: "Messages", prefertLargeTitle: true)
        fetchConversation()
       tableView.reloadData()
    }
    //MARK: - Selectors
    @objc func showNewMessageController()
    {
        let newMessage = NewMessageController()
        newMessage.delegate = self // confirm delegate, delegate variable is from newMessage controller which represent the protocol of NewMessageControllerDelegate. it has to set
        let nav = UINavigationController(rootViewController: newMessage)
        nav.modalPresentationStyle = .fullScreen
        present(nav, animated: true, completion: nil)
    }
    @objc func showProfile()
    {
        let controller = ProfileController(style: .insetGrouped) //style of tableview
        controller.delegate = self
        let nav = UINavigationController(rootViewController: controller)
        nav.modalPresentationStyle = .fullScreen    
        present(nav, animated: true, completion: nil)
        
    }
    //MARK: -API
    func fetchConversation() {
        showLoader(true)
        Service.fetchConversation { conversations in
            conversations.forEach { conversation in
                let message = conversation.message
                self.conversationDictionary[message.chatPartnerId] = conversation
            }
            self.showLoader(false)
            self.conversations = Array(self.conversationDictionary.values) //create array of updated values
            self.tableView.reloadData()
        }
    } //fetching recent messages from db
    
    func authenticateUSER() // this function check user is logged in or not if its is logged it will work and if not login controller wll present
    
    {
        if Auth.auth().currentUser?.uid == nil{
            presentLoginScreen()
        }else
        {
            print("User logged in\(String(describing: Auth.auth().currentUser?.uid))")
        }
    }
    func logout()  { //signing out the user
        do
        {
           try Auth.auth().signOut()
            presentLoginScreen()
        }
        catch{
            print("error in sign out")
        }
    }
    
    //MARK: - Helper
    
    func showChatController(_ user : User)
    {
        let controller = ChatController(user: user)
        navigationController?.pushViewController(controller, animated: true)
    }
    func presentLoginScreen() {//help to navigate to the loging screen
        DispatchQueue.main.async {
            let controller = LoginController()
            controller.delegate = self
            let nav = UINavigationController(rootViewController: controller)
            nav.modalPresentationStyle = .fullScreen //cover full screen so user can't dismiss
            self.present(nav, animated: true, completion: nil)
        }
    }
    func configTableView()
    {
        tableView.backgroundColor = .white
        tableView.rowHeight = 80
        tableView.register(ConversationCell.self, forCellReuseIdentifier: reuseIdentifier) //imp
        tableView.tableFooterView = UIView() //disappear lines from tableview
        tableView.delegate = self
        tableView.dataSource = self
        view.addSubview(tableView)
        tableView.frame = view.frame
        
    }
    func configUI() {
        view.backgroundColor = .white
        configTableView()
        navigationItem.leftBarButtonItem = UIBarButtonItem(image:UIImage(systemName: "person.circle.fill"), style:.plain, target: self, action: #selector(showProfile))
        view.addSubview(newMessage)
        newMessage.setDimensions(height: 56, width: 56)
        newMessage.layer.cornerRadius = 56 / 2
        newMessage.anchor(bottom:view.safeAreaLayoutGuide.bottomAnchor, right: view.rightAnchor,paddingBottom: 16,paddingRight: 24)
        
    }
    
}


extension ConversationController : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return conversations.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath) as! ConversationCell
        cell.conversation = conversations[indexPath.row]
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let user = conversations[indexPath.row].user
        showChatController(user)
    }
    
}

extension ConversationController : NewMessageControllerDelegate{ //needs to confirm delegate in showNewMessageController
    func controller(_ controller: NewMessageController, wantsToChatWith user: User) {
        print(user.userName)
        dismiss(animated: true, completion: nil)
        showChatController(user)
    }
}
 //MARK: -ProfileControllerDelegate

extension ConversationController : ProfileControllerDelegate{
    func handleLogOut() {
        logout()
    }
} //this will go to ProfileControllerDelegate then go to profilefooterdelegate

//MARK: -AuthenticationDelegate

extension ConversationController : AuthenticationDelegate
{
    func authenticationComplete() {
        dismiss(animated: true, completion: nil)
        configUI()
        fetchConversation()
    }
    
    
}
