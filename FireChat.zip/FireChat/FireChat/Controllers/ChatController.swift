//
//  ChatController.swift
//  FireChat
//
//  Created by Prachi on 2021-03-12.
//

import UIKit
private let reuseIdentifier : String = "MessageCell"
class ChatController : UICollectionViewController{
    
    //MARK: -Properties
    
    private var messages = [Message]()
    var fromCurrentUser =  false
     
    private lazy var customInputView : CustomInputAccessoryView =
        {
            let iv = CustomInputAccessoryView(frame: CGRect(x: 0, y: 0, width:view.frame.width, height: 50))
            iv.delegate = self //imp
          return iv
        }()
    private let user : User
    //MARK:- Lifecycle
    init(user : User)
    {
        self.user = user
        super.init(collectionViewLayout: UICollectionViewFlowLayout()) //imp to pass UICollectionViewFlowLayout
    }//this init is represent user with we are chatting
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configUI()
        fetchMessages()
    }
    
    override var inputAccessoryView: UIView?
    {
        get { return customInputView }
    }
    
    override var canBecomeFirstResponder: Bool{
        return true
    }
    //MARK: - Helper
    func configUI() {
        collectionView.backgroundColor = .white
        configureNavigationBar(withTitle: user.fullName, prefertLargeTitle: false)
        collectionView.register(MessageCell.self, forCellWithReuseIdentifier: reuseIdentifier) //imp
        collectionView.alwaysBounceVertical=true
        collectionView.keyboardDismissMode = .interactive
    }
}
//MARK: - Selectors

extension ChatController
{
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return messages.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! MessageCell
        cell.message = messages[indexPath.row]
        cell.message?.user = user //set user for profilepicture
        return cell
    }
}


extension ChatController : UICollectionViewDelegateFlowLayout
{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return .init(top: 16, left: 0, bottom: 16, right: 0)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize { //make messagecell responsive
       // return CGSize(width: view.frame.width, height: 50)
        
        let frame = CGRect(x: 0, y: 0, width: view.frame.width, height: 50)
        let estimatedSizeCell = MessageCell(frame: frame)
        estimatedSizeCell.message = messages[indexPath.row]
        estimatedSizeCell.layoutIfNeeded() //if height is less than or equal to 50 its not gonna have anything out but if the height is more than 50 it will call  layoutIfNeeded()
        
        let targetSize = CGSize(width: view.frame.width, height: 1000)
        let estimetadeSize = estimatedSizeCell.systemLayoutSizeFitting(targetSize)
        return.init(width: view.frame.width, height: estimetadeSize.height) //systemLayoutSizeFitting figure out how tall cell should be based on estimatedSizeCell which is populate some message
    }
}

extension ChatController:CustomInputAccessoryViewDelegate
{
    func inputVeiew(_ inputView: CustomInputAccessoryView, wantsTosend message: String)
    { //this method invoke when user write a message and press send button, this method is from CustomInputAccessoryView
       
        Service.uploadMessage(message, to: user) { error in
            if let error = error
            {
                print(error.localizedDescription)
               return
            }
            inputView.clearMessageText()
        }
    }
    //MARK: - API

    func fetchMessages() {
        showLoader(true)
        Service.fetchMessages(user) { messages in
            self.showLoader(false)
            self.messages = messages
            self.collectionView.reloadData()
            self.collectionView.scrollToItem(at: [0,self.messages.count - 1], at: .bottom, animated: true) //every time scroll collectionview bottom and fetch messages means when user is typing and send button pressed collection view will directly moved to bottom and new message fetch
        }
    }

}

