//
//  Service.swift
//  FireChat
//
//  Created by Prachi on 2021-03-10.
//

import Foundation
import Firebase
//fetching user

struct Service
{
    static func fetchusers(completion:@escaping ([User]) -> Void)
    {
        COLLECTION_USERS.getDocuments { snapshot, error in
//           snapshot?.documents.forEach({ document in //data from database(users) is in document and its in form of dictionary
//                let dictionary = document.data()
//                let user = User(dictionary: dictionary) //passed dic in initializer
//            users.append(user) //whenever new user is creted it will appen in users array
//            completion(users) //excute completion
//           })
            guard var users = snapshot?.documents.map({User(dictionary: $0.data())}) else {return} //documents is creating user and data() is getting users from documents,$0 represent each user
            if let i = users.firstIndex(where:
                                            {$0.uid == Auth.auth().currentUser?.uid}) //checking where is the first occurence of current UID in users array, i reperesent the index where the first index of the id matches with current ID
            {
                users.remove(at: i)
            }
            completion(users)
        } //fetching all user from databse collection
        
    }
    
    
    static func fetchusersWithuID(withuID uid : String,completion:@escaping (User) -> Void)
    {
        COLLECTION_USERS.document(uid).getDocument { (snapshot, error) in
            guard let dictonary = snapshot?.data() else {return}
            
            let users = User(dictionary: dictonary)
            completion(users)
        }
    } //this function is for fetching user to populate data on main screen with recent message
    
    
    static func uploadMessage(_ message : String,to user : User, completion : @escaping ((Error?)->Void))
    {
        guard let currentID = Auth.auth().currentUser?.uid else {
            return
        }
        let data = ["text":message,
                    "fromID":currentID,
                    "toID":user.uid, //id of a person to whome message will sent
                    "timeStamp":Timestamp(date: Date())]
            as [String : Any] //this will cast into dic
        //COLLECTION_MESSAGES -> create message collection in database like user
    COLLECTION_MESSAGES.document(currentID).collection(user.uid) .addDocument(data: data) { _ in
    
            COLLECTION_MESSAGES.document(user.uid).collection(currentID).addDocument(data: data, completion:completion ) //add message into both users recciver and sender both
            
            //Populating recent messages in screen
            
      /* 1 */  COLLECTION_MESSAGES.document(currentID).collection("recent_messages").document(user.uid).setData(data)
            
        /* 2 */
        COLLECTION_MESSAGES.document(user.uid).collection("recent_messages").document(currentID).setData(data)
        // so 1 and 2 is two d/f structure for reflecting and saving messages to both sender and receiver
        //IMP : setData is override the information, it is set up the data. if the data is exist it will override and feeds data. if fromId and ToId is same it will override the data with new data.
        //we need to show recent massage on screen so recent_messages(in db) will contain last and recent message so we can directly pupulate that  msg
        
        }
    }
    
    static func fetchConversation(completion:@escaping([Conversation])-> Void)
    {
        var conversations = [Conversation]()
        guard let uID = Auth.auth().currentUser?.uid else {
            return
        }
        let query = COLLECTION_MESSAGES.document(uID).collection("recent_messages").order(by: "timeStamp")
        query.addSnapshotListener { (snapshot, error) in
            snapshot?.documentChanges.forEach({ change in
                let dictonary = change.document.data()
                
                let message = Message(dictionary: dictonary)
                
                //we have msg but we need user too
                self.fetchusersWithuID(withuID: message.chatPartnerId) { user in
                    let conversation = Conversation(user: user, message: message)
                    conversations.append(conversation)
                    completion(conversations)
                }
            })
        }//using addSnapshotListener bcz everytime recent messages are updated so it should refresh by itself. when we get new message it create entire new conversation so in coversation controller 1 user's two converstaions has created
        
        //so use dictonary bcz  value has been change and key will remain same to him we taking to
    }
    static func fetchMessages(_ forUser : User,completion : @escaping ([Message]) ->Void) //for particular user
    {
        var messages = [Message]()
        guard let currentID = Auth.auth().currentUser?.uid else {
            return
        }
        let query = COLLECTION_MESSAGES.document(currentID).collection(forUser.uid).order(by: "timeStamp") //ordering data by timestamp, go in currentID and find user.uid from list and order it as per timestamp
        query.addSnapshotListener { (snapshot, error) in
            snapshot?.documentChanges.forEach({ change in
                if change.type == .added //if change type is added means soething is added to query. it will append
                {
                    let dictonary = change.document.data()
                    
                    messages.append(Message(dictionary: dictonary))
                        //new message will append and completion will excutes.it will breakdown of message function
                    completion(messages)
                }
            }) //addsnapshotlistner bcz evry time message will add to db, app can notify with help of addSnapshotListener that message has been added so fethch data and give it back to app. so user no need to refresh messages evry time
        }
    }
}

