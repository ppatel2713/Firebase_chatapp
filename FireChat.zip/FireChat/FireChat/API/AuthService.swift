//
//  AuthService.swift
//  FireChat
//
//  Created by Prachi on 2021-03-09.
//

import Firebase
import  UIKit

struct RegistrationCredentials {
    let email : String
    let password : String
    let fullName : String
    let userName : String
    let profileImage : UIImage
}

struct AuthService { //this struct contains all stuff for reaching out to database and all authentication services
    static let shared  = AuthService() //bcz want to create one instance, it is more Afficient way
    func logUserIn(withEmail email:String, andWithPassword password:String,completion:AuthDataResultCallback?)
    {
        Auth.auth().signIn(withEmail: email, password: password, completion: completion)
        
    }
    
    //we create completion in argument bcz can not access view's methods so with completion handle view's methods and errors
    func createUser(credentials : RegistrationCredentials,completion:((Error?)-> Void)?)  {
        guard let imageData = credentials.profileImage.jpegData(compressionQuality: 0.5) else { return } //it compress size of image
        let fileName = NSUUID().uuidString
        let ref = Storage.storage().reference(withPath: "/profile_images/\(fileName)") //this create folder in database, name of folder is prfile_images and assign photo name(filename which is unique id)
        ref.putData(imageData, metadata: nil) { (meta, error) in
            if let error = error{
                completion!(error)
                return
            }
            ref.downloadURL { (url, error) in
                guard let profileImageURL = url?.absoluteString else { return } //url is created for image
              
                
                Auth.auth().createUser(withEmail: credentials.email, password: credentials.password) { (result, error) in //result is callback from firebase, we create user and response back in result
                    if let error = error{
                        completion!(error)
                        return
                    }// upload user data to database
                    
                    guard let uid = result?.user.uid else {return} //here user is part of result and its has user ID, so we can use it to identify user
                    let data = ["email" : credentials.email,
                                "fullname" : credentials.fullName,
                                "profileImageURl" : profileImageURL,
                                "uid" : uid,
                                "username" : credentials.userName] as [String : Any] //create dictionary to save data into database
                    Firestore.firestore().collection("users").document(uid).setData(data, completion:completion)
                }
            }
        }
        
        
        
    }
}
