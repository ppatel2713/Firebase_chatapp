//
//  ViewController.swift
//  FireChat
//
//  Created by Prachi on 2021-03-07.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

