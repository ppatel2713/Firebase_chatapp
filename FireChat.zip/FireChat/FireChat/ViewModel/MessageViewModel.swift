//
//  MessageViewModel.swift
//  FireChat
//
//  Created by Prachi on 2021-03-14.
//

import UIKit

struct MessageViewModel { //we need to decide bg color of sender and receivers mesaages. it will decide which side of message gone. is it from current user or from person with whom user is chatting.
    
    //MARK: - Properties
    private let message : Message
    
    var messageBackgroundColor : UIColor{
        return message.isFromCurrentUser ? #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1) : .systemPurple //is from current user is bool
    }
    
    
    var messageTextcolor : UIColor
    {
        return message.isFromCurrentUser ? #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1) : #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
    }
    
    init(message : Message)
    {
        self.message = message
    }
    
    var rightAnchorActive : Bool
    {
        return message.isFromCurrentUser //if message is from current user it will comes on right side
    }
    var leftAnchorActive : Bool
    {
        return !message.isFromCurrentUser //if its not from current user it will comes on left side
    }
    
    
    var shouldHideProfileImage : Bool
    {
        return message.isFromCurrentUser //if message from current user don't want to show profile image
    }
   
    var profileImageURl : URL? //show image in chatting
    {
        guard let user = message.user else {return nil}
        return URL(string: user.profileImageUrl)!
    }//already have image in system so this is the way to fetch image for chattinf page
}
