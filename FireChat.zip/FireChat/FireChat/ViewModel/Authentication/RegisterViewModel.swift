//
//  RegisterViewModel.swift
//  FireChat
//
//  Created by Prachi on 2021-03-08.
//

import UIKit


struct  RegisterViewModel : AuthenticationProtocol{
    var email : String?
    var password : String?
    var userName : String?
    var fullName : String?
    
    var isValidForm : Bool
    {
        return email?.isEmpty == false && password?.isEmpty == false && userName?.isEmpty == false && fullName?.isEmpty == false
    }
}
