//
//  LoginViewModel.swift
//  FireChat
//
//  Created by Prachi on 2021-03-08.
//

import UIKit
protocol AuthenticationProtocol {
    var isValidForm: Bool {get }
}


struct LoginViewModel : AuthenticationProtocol{
    var email : String?
    var password : String?
    
    var isValidForm : Bool
    {
        return email?.isEmpty == false && password?.isEmpty == false
    }
}
