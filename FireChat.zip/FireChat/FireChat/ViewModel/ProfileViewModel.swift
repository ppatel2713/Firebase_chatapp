//
//  ProfileViewModel.swift
//  FireChat
//
//  Created by Prachi on 2021-03-17.
//

import UIKit

enum ProfileViewModel : Int, CaseIterable { //create cell info, cell value will be decide on cell number so Int
    case accountInfo
    case settings
    
    var description : String
    {
        switch self
        {
            case .accountInfo : return "Account Info"
            case .settings : return "Settings"
        }
    } //text
    
    var iconImageName : String
    {
        switch self
        {
            case .accountInfo : return "person.circle"
            case .settings : return "gear"
        }
    } //image
    
}
